import React from 'react';

const Background = () => {
    return (
        <div>
            <img src={require('../../utilities/images/layout/background1.png')} alt="" className="w-100" />
        </div>
    );
};

export default Background;