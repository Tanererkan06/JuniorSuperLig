import React from 'react';
import './Background2.css'
const Background2 = () => {
    return (
        <div className='bg-2'>
            <img src={require('../../utilities/images/layout/background1.png')} alt="" className="w-100" />
        </div>
    );
};

export default Background2;