********************************
**					**	 
**   iGen Solutions Limited   ** 
**					**
********************************

To run the project just follow below 2 line code in your terminal or command prompt while you are in project directory

	"yarn install"

		after yarn install all packages then hit
	"yarn start"
		your project will run in your local machine 

If you want to deploy to server just hit this code
	"yarn build"
		after successfully build your project into build directory then just move to your server www root directory


If you are newly installing react js just follow those link and our details Documentation

  i) https://nodejs.org/en/
  ii)https://classic.yarnpkg.com/en/docs/install#windows-stable


Thanks you so much buy our script 
And please don't forget to rated us:
https://codecanyon.net/user/igensolutionsltd